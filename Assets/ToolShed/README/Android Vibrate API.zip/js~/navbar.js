/*
 * Constants
 */

const ID_DIM = 'navbar-dim';
const ID_WRAPPER = 'navbar-wrapper';
const ID_BUTTON = 'navbar-toggle';
const ID_BACK_TO_TOP = 'navbar-back-to-top';
const ID_CONTENT = 'content';
const ID_SEARCH_CLEAR = 'navbar-search-clear';
const ID_SEARCH_INPUT = 'navbar-search-input';
const CLASS_OPEN = 'navbar-open';
const CLASS_ITEM = 'navbar-item';
const CLASS_EXPANDER = 'navbar-expander';
const CLASS_ITEM_SELECTED = 'navbar-item-selected';
const CLASS_CONTENT = 'content';
const ATT_KEY = 'data-key';
const ATT_INDENT = 'data-indent';
const ATT_KEYWORDS = 'data-keywords';
const PATH_OPEN = 'images~/navigate-right.png';
const PATH_CLOSE = 'images~/navigate-left.png';
const PATH_EXPANDER_DOWN = 'images~/menu-down.png';
const PATH_EXPANDER_RIGHT = 'images~/menu-right.png';
 
/*
 *	Navbar class definition
 */

class Navbar {
	 
	constructor(defaultHash) {
		this.items = [];
		var elements = document.getElementsByClassName(CLASS_ITEM);
		for (var i = 0; i < elements.length; i++) {
			var element = elements[i];
			if (element.getAttribute(ATT_INDENT) == "0") {
				this.items[this.items.length] = new NavbarItem(element, null);
			}
		}
		this.contents = document.getElementsByClassName(CLASS_CONTENT);
		window.addEventListener("resize", this.onResize);
		window.addEventListener("scroll", this.onScroll);
		this.onResize(null);
		this.button = document.getElementById(ID_BUTTON);
		this.wrapper = document.getElementById(ID_WRAPPER);
		
		// open to hash
		if (!this.navigateTo(window.location.hash)) {
			this.navigateTo(defaultHash);
		}
		
		window.addEventListener("hashchange", this.onHashChange);
	}
	
	onResize(event) {
		var wrapper = document.getElementById(ID_WRAPPER);
		wrapper.style.height = (Math.max(document.documentElement.clientHeight, window.innerHeight || 0) - 36) + 'px';
		
		if (window.innerWidth < 600 && !wrapper.classList.contains(CLASS_OPEN)) {
			wrapper.style.left = '-276px';
		} else {
			wrapper.style.left = '0px';
		}
	}
	
	onHashChange() {
		if (navbarLastKnownHash != window.location.hash) {
			navbarLastKnownHash = window.location.hash;
			navbar.navigateTo(window.location.hash);
		}
	}
	
	open() {
		if (this.wrapper.classList.contains(CLASS_OPEN)) {
			this.wrapper.classList.remove(CLASS_OPEN);
			this.button.childNodes[0].setAttribute('src', PATH_OPEN);
			var dim = document.getElementById(ID_DIM);
			dim.style.display = 'none';
		} else {
			this.wrapper.classList.add(CLASS_OPEN);
			this.button.childNodes[0].setAttribute('src', PATH_CLOSE);
			var dim = document.getElementById(ID_DIM);
			dim.style.display = 'block';
		}
		this.onResize(null);
	}
	
	toggle(event, element) {
		event.stopPropagation();
		var item = this.findItem(this.items, element.parentElement.getAttribute(ATT_KEY));
		if (item != null) {
			item.toggle();
		}
	}

	view(element) {
		var contentId = element.getAttribute(ATT_KEY);
		var content = document.getElementById(contentId);
		if (content != null) {
			for (var i = 0; i < this.contents.length; i++) {
				this.contents[i].style.display = 'none';
			}
			content.style.display = 'initial';
			for (var i = 0; i < this.items.length; i++) {
				this.items[i].deselect();
			}
			element.classList.add(CLASS_ITEM_SELECTED);
			navbarLastKnownHash = '#' + contentId;
			window.location.hash = '#' + contentId;
			window.scrollTo(0,0);
		}
	}

	findItem(items, key) {
		for (var i = 0; i < items.length; i++) {
			if (items[i].key == key) {
				return items[i];
			}
		}
		var item = null;
		for (var i = 0; i < items.length; i++) {
			item = this.findItem(items[i].children, key);
			if (item != null) {
				return item;
			}
		}
		return null;
	}

	search(input) {
		if (input.value != '') {
			document.getElementById(ID_SEARCH_CLEAR).style.visibility = 'initial';
			var phrase = input.value.split(' ');
			for (var i = 0; i < this.items.length; i++) {
				this.items[i].search(phrase);
			}
		} else {
			this.clearSearch();
		}
	}

	clearSearch() {
		document.getElementById(ID_SEARCH_INPUT).value = '';
		document.getElementById(ID_SEARCH_CLEAR).style.visibility = 'hidden';
		for (var i = 0; i < this.items.length; i++) {
			this.items[i].update();
		}
	}
	
	// typically not necessary because
	// navbar listens for changes in window.location.hash
	navigateTo(hash) {
		var split = hash.split('#');
		// node
		var item = this.findItem(this.items, split[1]);
		if (item != null) {
			item.expandParents();
			this.view(item.element);
			// subnode
			if (split.length > 2) {
				item.scrollTo(split[2]);
				navbarLastKnownHash = hash;
				window.location.hash = hash;
			}
			return true;
		} else {
			return false;
		}
	}
	
	backToTop() {
		var split = window.location.hash.split('#');
		navbarLastKnownHash = '#' + split[1];
		window.location.hash = '#' + split[1];
		window.scrollTo(0,0);
	}
	
	onScroll() {
		var button = document.getElementById(ID_BACK_TO_TOP);
		if (window.scrollY > 0) {
			//button.style.display = 'flex';
			button.style.transform = 'scale(1,1)';
		} else {
			//button.style.display = 'none';
			button.style.transform = 'scale(0,0)';
		}
	}
}
 
/*
 * NavbarItem class definition
 */
 
class NavbarItem {
	
	constructor(element, parent) {
		this.expandedInHierarchy = false;
		this.parent = parent;
		this.caret = null;
		for (var i = 0; i < element.children.length; i++) {
			if (element.children[i].classList.contains(CLASS_EXPANDER)) {
				this.caret = element.children[i];
				break;
			}
		}
		if (this.parent == null) {
			this.parent = this;
			this.expandedInHierarchy = true;
		}
		this.expanded = false;
		this.element = element;
		this.key = element.getAttribute(ATT_KEY);
		this.content = document.getElementById(this.key);
		if (this.content != null) {
			this.content.style.display = 'none';
		}
		this.indentLevel = Number(element.getAttribute(ATT_INDENT));
		this.children = [];
		this.keywords = element.getAttribute(ATT_KEYWORDS);
		if (this.keywords == null) {
			this.keywords = '';
		}
		
		if (this.indentLevel > 0) {
			this.element.style.display = 'none';
		}
		
		// discover and initialize children
		var child = element.nextElementSibling;
		if (child != null) {
			var nextSiblingIndentLevel = Number(child.getAttribute(ATT_INDENT));
			var count = 0;
			while (nextSiblingIndentLevel == this.indentLevel + 1) {
				this.children[count++] = new NavbarItem(child, this);
				child = child.nextElementSibling;
				if (child != null) {
					nextSiblingIndentLevel = Number(child.getAttribute(ATT_INDENT));
				} else {
					return;
				}
			}
		}
	}
	
	toggle() {
		this.expanded = !this.expanded;
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].update();
		}
		if (this.caret != null) {
			if (this.expanded) {
				this.caret.setAttribute('src', PATH_EXPANDER_DOWN);
			} else {
				this.caret.setAttribute('src', PATH_EXPANDER_RIGHT);
			}
		}
	}
	
	update() {
		if ((this.parent.expanded && this.parent.expandedInHierarchy) || this.parent == this) {
			this.element.style.display = 'block';
			this.expandedInHierarchy = true;
		} else {
			this.element.style.display = 'none';
			this.expandedInHierarchy = false;
		}
		if (this.caret != null) {
			this.caret.style.visibility = 'initial';
			if (this.expanded) {
				this.caret.setAttribute('src', PATH_EXPANDER_DOWN);
			} else {
				this.caret.setAttribute('src', PATH_EXPANDER_RIGHT);
			}
		}
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].update();
		}
	}
	
	deselect() {
		this.element.classList.remove(CLASS_ITEM_SELECTED);
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].deselect();
		}
	}
	
	expandParents() {
		if (this.parent != this) {
			this.parent.expanded = true;
			this.parent.caret.setAttribute('src', PATH_EXPANDER_DOWN);
			this.parent.expandParents();
		} else {
			this.update();
		}
	}
	
	search(phrase) {
		var match = true;
		for (var i = 0; i < phrase.length; i++) {
			if (!this.keywords.includes(phrase[i])) {
				match = false;
				break;
			}
		}
		if (match) {
			this.element.style.display = 'block';
			this.showParents();
		} else {
			this.element.style.display = 'none';
		}
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].search(phrase);
		}
	}
	
	showParents() {
		this.parent.element.style.display = 'block';
		if (this.parent.caret != null) {
			this.parent.caret.style.visibility = 'hidden'
		}
		if (this.parent != this) {
			this.parent.showParents();
		}
	}
	
	scrollTo(id) {
		var element = document.getElementById(id);
		if (element != null) {
			window.scrollTo(0, element.getBoundingClientRect().top);
		}
	}
}

/*
 *	Variables
 */

var navbarLastKnownHash = '';
var navbar = null;
if (typeof navbarDefaultHash !== 'undefined') {
	navbar = new Navbar(navbarDefaultHash);
} else {
	navbar = new Navbar('');
}